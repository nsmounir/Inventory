package com.example.android.inventory;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.support.design.widget.FloatingActionButton;
import android.widget.TextView;

import com.example.android.inventory.Data.Contract;
import com.example.android.inventory.Data.DbHelper;

public class MainActivity extends AppCompatActivity {

    private DbHelper mDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Setup FAB to open EditorActivity
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, EditorActivity.class);
                startActivity(intent);
            }
        });

//        Instantiate subclass of SQLiteOpenHelper to access data

        mDbHelper = new DbHelper(this);
        displayDatabaseInfo();

    }

    public void displayDatabaseInfo() {
        mDbHelper = new DbHelper(this);

        // Create and/or open a database to read from it
        SQLiteDatabase db = mDbHelper.getReadableDatabase();

        // Perform this raw SQL query "SELECT * FROM books"
        // to get a Cursor that contains all rows from the books table.
        String[] projection = {Contract.BookEntry._ID, Contract.BookEntry.COLUMN_BOOK_NAME, Contract.BookEntry.COLUMN_PRICE,
                Contract.BookEntry.COLUMN_QUANTITY, Contract.BookEntry.COLUMN_SUPPLIER_NAME, Contract.BookEntry.COLUMN_SUPPLIER_PHONE_NUMBER};
        Cursor cursor = db.query(Contract.BookEntry.TABLE_NAME, projection, null, null, null, null, null);
        TextView displayView = (TextView) findViewById(R.id.book_db);

        try {
            // Create a header in the Text View that looks like this:
            //
            // The books table contains <number of rows in Cursor> books.
            //
            // In the while loop below, iterate through the rows of the cursor and display
            // the information from each column in this order.
            displayView.setText(getResources().getString(R.string.the_books_table_contains) + " " + cursor.getCount() + " "
                    + getResources().getString(R.string.books) + "\n\n");
            displayView.append(Contract.BookEntry._ID + " - " +
                    Contract.BookEntry.COLUMN_BOOK_NAME + " - " +
                    Contract.BookEntry.COLUMN_PRICE + " - " +
                    Contract.BookEntry.COLUMN_QUANTITY + " - " +
                    Contract.BookEntry.COLUMN_SUPPLIER_NAME + " - " +
                    Contract.BookEntry.COLUMN_SUPPLIER_PHONE_NUMBER + "\n");

            // Figure out the index of each column
            int idColumnIndex = cursor.getColumnIndex(Contract.BookEntry._ID);
            int nameColumnIndex = cursor.getColumnIndex(Contract.BookEntry.COLUMN_BOOK_NAME);
            int priceColumnIndex = cursor.getColumnIndex(Contract.BookEntry.COLUMN_PRICE);
            int quantityColumnIndex = cursor.getColumnIndex(Contract.BookEntry.COLUMN_QUANTITY);
            int supplierNameColumnIndex = cursor.getColumnIndex(Contract.BookEntry.COLUMN_SUPPLIER_NAME);
            int supplierPhoneColumnIndex = cursor.getColumnIndex(Contract.BookEntry.COLUMN_SUPPLIER_PHONE_NUMBER);

            // Iterate through all the returned rows in the cursor
            while (cursor.moveToNext()) {
                // Use that index to extract the String or Int value of the word
                // at the current row the cursor is on.
                int currentID = cursor.getInt(idColumnIndex);
                String currentName = cursor.getString(nameColumnIndex);
                int currentPrice = cursor.getInt(priceColumnIndex);
                int currentQuantity = cursor.getInt(quantityColumnIndex);
                String currentSupplierName = cursor.getString(supplierNameColumnIndex);
                int currentSupplierPhone = cursor.getInt(supplierPhoneColumnIndex);

                // Display the values from each column of the current row in the cursor in the TextView
                displayView.append(("\n" + currentID + " - " +
                        currentName) + " - " + currentPrice + " - " + currentQuantity + " - " + currentSupplierName + " - " + currentSupplierPhone);
            }
        } finally {
            // Close cursor
            cursor.close();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

}
