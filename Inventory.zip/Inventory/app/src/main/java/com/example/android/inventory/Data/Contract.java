package com.example.android.inventory.Data;

import android.provider.BaseColumns;

public final class Contract {
    private Contract() {
    }

    public static abstract class BookEntry implements BaseColumns {
        public static final String TABLE_NAME = "Books";
        public static final String _ID = BaseColumns._ID;
        public static final String COLUMN_BOOK_NAME = "BookName";
        public static final String COLUMN_PRICE = "Price";
        public static final String COLUMN_QUANTITY = "Quantity";
        public static final String COLUMN_SUPPLIER_NAME = "Supplier";
        public static final String COLUMN_SUPPLIER_PHONE_NUMBER = "SupplierPhone";

    }
}
